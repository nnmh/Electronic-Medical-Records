package EMR;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.imageio.stream.FileImageInputStream;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

import fr.apteryx.imageio.dicom.DicomMetadata;
import fr.apteryx.imageio.dicom.DicomReader;
import fr.apteryx.imageio.dicom.Tag;
public class file {
	public static void main(String[] args) throws IOException {
		Dicom d = new Dicom();
		File dir = new File("G:\\Moataz\\workspace\\EMR");

		System.out.println("Getting all files in " + dir.getCanonicalPath() + " including those in subdirectories");
		List<File> files = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
		for (File file : files) {
			//
			 if (file.getName().endsWith(".dcm")) {
				System.out.println("file: " + file.getCanonicalPath());
				d.dcm(file);
			 }
		}

	}

}

