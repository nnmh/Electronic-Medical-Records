package EMR;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;

public class Parser {
	Pdf db = new Pdf();
	   public void main(String Patient_Name,String Patient_id) throws IOException {
	        PDFTextStripper pdfStripper = null;
	        PDDocument pdDoc = null;
	        COSDocument cosDoc = null;
	        File dir = new File("G:\\Moataz\\workspace\\EMR\\pdf&dicom");
	        System.out.println("Getting all files in " + dir.getCanonicalPath() + " including those in subdirectories");
			List<File> files = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
			for (File file : files) {
				//
				 if (file.getName().endsWith(".pdf")) {
					System.out.println("file: " + file.getCanonicalPath());
		        try {
		            PDFParser parser = new PDFParser(new FileInputStream(file));
		            parser.parse();
		            cosDoc = parser.getDocument();
		            pdfStripper = new PDFTextStripper();
		            pdDoc = new PDDocument(cosDoc);
		            pdfStripper.setStartPage(1);
		            pdfStripper.setEndPage(1);
		            String parsedText = pdfStripper.getText(pdDoc);
		            System.out.println(parsedText);
		            if(parsedText.equals(Patient_Name))
		            {
		            	System.out.println("true");
		            	db.main(file,Patient_id);
		            }
		            else{System.out.println("NOT MATCHED");}
		        }catch (IOException e) {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        }finally {
		        	cosDoc.close(); 
					 }
				}
			}
	   }
}
