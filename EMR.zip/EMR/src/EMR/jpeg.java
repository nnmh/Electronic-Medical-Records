package EMR;

import javax.swing.*;

import org.dcm4che2.imageio.plugins.dcm.DicomImageReadParam;

import com.sun.media.jai.codecimpl.JPEGCodec;

import java.io.*;
import java.awt.image.*;
import java.awt.*;
import javax.imageio.*;
import javax.imageio.stream.*;
import java.util.Iterator;

import fr.apteryx.imageio.dicom.*;
import fr.apteryx.imageio.dicom.DicomException;
import fr.apteryx.imageio.dicom.DicomMetadata;
	import fr.apteryx.imageio.dicom.DicomReader;
	import fr.apteryx.imageio.dicom.Tag;
public class jpeg {
	
	public static void main(String[] s) {
		     
			File f = new File("G:\\Moataz\\workspace\\EMR\\pdf&dicom\\MR-MONO2-8-16x-heart.dcm");
			BufferedImage myJpegImage = null;
			Iterator<ImageReader> iter = ImageIO.getImageReadersByFormatName("DICOM");
			ImageReader reader = (ImageReader) iter.next();
			//DicomImageReadParam param = (DicomImageReadParam) reader.getDefaultReadParam();
			try {
				reader.setInput(new FileImageInputStream(f));
				DicomMetadata dmd = (DicomMetadata) reader.getStreamMetadata();

			      int n = reader.getNumImages(true);

			      for (int i=0; i<n; i++) {
			        BufferedImage bi_stored = reader.read(i);
			        if (bi_stored == null) {
			          System.err.println("read error");
			          System.exit(1);
			        }

			        BufferedImage bi = dmd.applyGrayscaleTransformations(bi_stored, i);
			      
			        BufferedImage bi_out = new BufferedImage(bi.getWidth(),
			            bi.getHeight(), BufferedImage.TYPE_3BYTE_BGR);
			        bi_out.createGraphics().drawImage(bi, 0, 0, null);

			        File f_out = new File("i"+i+".jpg");
			        f_out.delete();
			        ImageIO.write(bi_out, "jpeg", f_out);
			        System.out.println("written: "+f_out);
			      }
			} 
			catch(IOException e) {
			   System.out.println("\nError: couldn't read dicom image!"+ e.getMessage());
			   return;
			}



  
		  }

}