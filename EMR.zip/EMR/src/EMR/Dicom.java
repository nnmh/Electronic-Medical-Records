package EMR;
import  DB.*; 
import java.awt.image.BufferedImage;
	import java.awt.image.Raster;
	import java.io.BufferedOutputStream;
	import java.io.DataOutputStream;
	import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.util.*;

	import javax.imageio.ImageIO;
	import javax.imageio.ImageReader;
	import javax.imageio.stream.FileImageInputStream;
	import javax.imageio.stream.ImageInputStream;

import fr.apteryx.imageio.dicom.DicomException;
import fr.apteryx.imageio.dicom.DicomMetadata;
	import fr.apteryx.imageio.dicom.DicomReader;
	import fr.apteryx.imageio.dicom.Tag;
public class Dicom {
		db data = new db();
		Parser p =new Parser();
		public void dcm(File file) throws FileNotFoundException, IOException{
			Iterator iter= ImageIO.getImageReadersByFormatName("Dicom") ;
			DicomReader reader = (DicomReader)iter.next();
			FileImageInputStream iis = new FileImageInputStream(file);
			reader.setInput(iis  , false);		
			DicomMetadata dmd = reader.getDicomMetadata();
			String patient_Name = dmd.getAttributeString(Tag.PatientsName);
			String patient_id = dmd.getAttributeString(Tag.PatientID);
			String patient_Age = dmd.getAttributeString(Tag.PatientsAge);
			String patient_Sex = dmd.getAttributeString(Tag.PatientsSex);
			String Modality = dmd.getAttributeString(Tag.Modality);
			String Acessation_Numder = dmd.getAttributeString(Tag.AccessionNumber);
			
			//data.patient(patient_Name, patient_id, patient_Age, patient_Sex);
			p.main(patient_Name,patient_id);
			System.out.println(patient_Name);
			System.out.println(patient_id);
			System.out.println(patient_Age);
			System.out.println(patient_Sex);

			
		}
	}
